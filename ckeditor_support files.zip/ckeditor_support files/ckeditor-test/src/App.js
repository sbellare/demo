import React, { Component } from 'react';
import { CKEditor } from '@ckeditor/ckeditor5-react';
//import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
//import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';
//import ClassicEditorWithTrackChanges from '@ckeditor/track-changes-integration';
//import TrackChanges from '@ckeditor/ckeditor5-track-changes/src/trackchanges';
//import Bold from '@ckeditor/ckeditor5-basic-styles/src/bold';
//import ClassicExtended from "ckeditor5-build-classic-extended";
import Editor from "ckeditor5-custom-build"

const editorConfiguration = {
  licenseKey:'YNT4/cD90AwQmstlcwtW6R2PQ6b180mn/dSqtATK5VwoZNpwvqbB+Dm4+Q==', 
  toolbar: [
    'bold',
    'italic',
    'underline',
    'subscript',
    'superscript',
    'Strikethrough',
    '|',
    'List',
    'bulletedList',
    'numberedList',
    'outdent',
    'indent',
    '|',
    //'PasteFromOffice',
    'undo',
    'redo',
    '|',
    'link',
   // 'heading',
   '|',
   //'tableproperties',
    'imageupload',
    '|',
    'trackchanges',
    '|',
    'ExportWord',
    'ExportPdf'
  ]
  //plugins: [ Essentials, Bold, Italic, Paragraph ],
  //plugins: [ TrackChanges ],
      // toolbar: ['pastefromoffice']
      // toolbar: {
      //     items: [
      //         'heading',
      //         '|',
      //         'bold',
      //         'italic',
      //         'underline',
      //         'strikethrough',
      //         'subscript',
      //         'superscript',
      //         '|',
      //         'bulletedList',
      //         'numberedList',
      //         'todoList',
      //         '|',
      //         'alignment',
      //         'outdent',
      //         'indent',
      //                      '|','link', 'unlink',
      //             '|', 'insertTable','imageUpload', 
      //     ]}
      //     removeButtons: 'Subscript,Superscript'
      //    toolbar: [{ items: [ 'Underline', 'Italic', 'Bold' ] }
      //  ],
      //  removeButtons: 'Subscript,Superscript'
      };
class App extends Component {
    render() {
        return (
            <div className="App">
                <h2>Using CKEditor 5 build in React</h2>
                <CKEditor
                    //editor={ ClassicEditor }
                    //editor={ ClassicEditorWithTrackChanges }
                    //editor={ ClassicExtended }
                    editor={ Editor }
                    config={ editorConfiguration }
                    data="<p>Hello from CKEditor 5!</p>"
                    onReady={ editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log( 'Editor is ready to use!', editor );
                    } }
                    onChange={ ( event, editor ) => {
                        const data = editor.getData();
                        console.log( { event, editor, data } );
                    } }
                    onBlur={ ( event, editor ) => {
                        console.log( 'Blur.', editor );
                    } }
                    onFocus={ ( event, editor ) => {
                        console.log( 'Focus.', editor );
                    } }
                />
            </div>
        );
    }
}

export default App;